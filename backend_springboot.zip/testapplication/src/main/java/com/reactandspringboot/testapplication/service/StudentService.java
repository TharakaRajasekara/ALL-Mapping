package com.reactandspringboot.testapplication.service;

import com.reactandspringboot.testapplication.dto.StudentDetailsDTO;

public interface StudentService {

    public String saveStudent(StudentDetailsDTO studentDetailsDTO);
}
