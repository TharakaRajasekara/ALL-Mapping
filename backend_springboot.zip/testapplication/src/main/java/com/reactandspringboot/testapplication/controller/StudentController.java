package com.reactandspringboot.testapplication.controller;

import com.reactandspringboot.testapplication.dto.StudentDetailsDTO;
import com.reactandspringboot.testapplication.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("student/info")
@CrossOrigin
public class StudentController {

    @Autowired
    private StudentService studentService;

    @PostMapping("/save")
    public String saveStudent(@RequestBody StudentDetailsDTO studentDetailsDTO){
        studentService.saveStudent(studentDetailsDTO);
        return "student saved";
    }

}
