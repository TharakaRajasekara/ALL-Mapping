package com.reactandspringboot.testapplication.service.IMPL;

import com.reactandspringboot.testapplication.dto.StudentDetailsDTO;
import com.reactandspringboot.testapplication.entity.StudentDetails;
import com.reactandspringboot.testapplication.repository.StudentRepository;
import com.reactandspringboot.testapplication.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StudentServiceIMPL implements StudentService {

    @Autowired
    private StudentRepository studentRepository;


    @Override
    public String saveStudent(StudentDetailsDTO studentDetailsDTO) {
        StudentDetails studentDetails = new StudentDetails(
                studentDetailsDTO.getId(),
                studentDetailsDTO.getName(),
                studentDetailsDTO.getAge(),
                studentDetailsDTO.getAddress(),
                studentDetailsDTO.getContact()
        );
        studentRepository.save(studentDetails);
        return "student saved succussfully";
    }
}
