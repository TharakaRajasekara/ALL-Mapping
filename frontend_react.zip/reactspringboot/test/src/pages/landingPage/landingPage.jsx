import React from "react";
import './landingPage.css';


const LandingPage = () =>{

    const submitInfo = ()=>{

        let studentName = document.getElementById('name').value
        let studentAge = document.getElementById('age').value
        let studentAddress = document.getElementById('address').value
        let studentContact = document.getElementById('contact').value

        var obj ={
            name : studentName,
            age : studentAge,
            address :studentAddress,
            contact : studentContact
        }
        console.log(obj);
        fetch("http://192.168.8.142:8080/student/info/save",{
          
          method:"POST",
          headers:{
            'Content-type': 'application/json'
          },
          body:JSON.stringify(obj)
          
        }).then((response) => response.json())
        .then((json) => console.log(json));
        console.log(response.json());
    }



    return(
<>
<div className="main_body">

<div className="regform_main">

    <input type="text" id="name" className='input_field' placeholder="enter your name"></input>
    <input type="number" id="age" className='input_field' placeholder="enter your age"></input>
    <input type="text" id="address" className='input_field' placeholder="enter your address"></input>
    <input type="text" id="contact" className='input_field' placeholder="enter your contact number"></input><br></br>

    <button className="submit_button"  onClick={()=>{submitInfo()}}>SUBMIT</button>

</div>
</div>

</>
    )
}
export default LandingPage;